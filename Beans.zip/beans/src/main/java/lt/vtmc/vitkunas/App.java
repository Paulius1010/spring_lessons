package lt.vtmc.vitkunas;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");

		Human humanBean = (Human) context.getBean("humanBean");
		System.out.println("Hello bean which " + humanBean.getResult());

		Shape shape = (Shape) context.getBean("shapeBean");
		System.out.println("Hello shape which " + shape.getResult());

		Square square = (Square) context.getBean("squareBean");
		System.out.println("Hello square which " + square.getResult());

		Rectangle rectangle = (Rectangle) context.getBean("rectangleBean");
		System.out.println("Hello rectangle which " + rectangle.getResult());

		Circle circle = (Circle) context.getBean("circleBean");
		System.out.println("Hello circle which " + circle.getResult());

		((ConfigurableApplicationContext) context).close();
	}
}
