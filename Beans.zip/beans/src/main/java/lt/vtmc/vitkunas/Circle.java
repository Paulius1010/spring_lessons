package lt.vtmc.vitkunas;

public class Circle {

	private int area;
	private String color;
	private String message;

	public Circle(int area, String color, String message) {
		super();
		this.area = area;
		this.color = color;
		this.message = message;
	}

	public Circle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getArea() {
		return area;
	}

	public void setArea(int area) {
		this.area = area;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getResult() {
		return "message is: " + getMessage();
	}

	public void showWhenInitializing() {
		System.out.println("When initializing: Circle message is " + getMessage() + " and color is " + getColor());
	}

	public void showWhenDestroying() {
		System.out.println("When destroying: Circle message was " + getMessage() + " and color was " + getColor());
	}

}
