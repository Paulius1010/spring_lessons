package lt.vtmc.vitkunas;

public class Human {
	private String name;
	private int age;

	public Human(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public Human() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getResult() {
		return "name is: " + getName();
	}

	public void showWhenInitializing() {
		System.out.println("When initializing: Human Bean name is " + getName() + " and age is " + getAge());
	}

	public void showWhenDestroying() {
		System.out.println("When destroying: Human Bean name was " + getName() + " and age was " + getAge());
	}

}
