package lt.vtmc.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");
		ServiceA serviceA = (ServiceA) context.getBean("serviceABean");
		System.out.println("Service A result:" + serviceA.getResult());
		ServiceB serviceB = (ServiceB) context.getBean("serviceBBean");
		System.out.println("Service B result:" + serviceB.getResult());
		ServiceC serviceC = (ServiceC) context.getBean("serviceCBean");
		System.out.println("Service C result:" + serviceC.getResult());
		((ConfigurableApplicationContext) context).close();
	}
}
