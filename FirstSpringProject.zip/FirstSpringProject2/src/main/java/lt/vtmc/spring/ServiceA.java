package lt.vtmc.spring;

public class ServiceA {
	private String message;

	public String getResult() {
		return "ServiceA result: " + getMessage();
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void showWhenInitializing() {
		System.out.println("When initializing serviceA Bean " + getMessage());
	}

	public void showWhenDestroying() {
		System.out.println("When destroying serviceA Bean " + getMessage());
	}

}
