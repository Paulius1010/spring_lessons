package lt.vtmc.spring;

public class ServiceB {
	private ServiceA serviceA;

	public ServiceB(ServiceA serviceA) {
		super();
		this.serviceA = serviceA;
	}

//	public void setServiceA(ServiceA serviceA) {
//		this.serviceA = serviceA;
//	}

	public String getResult() {
		return "ServiceB getResult() method result: " + serviceA.getResult();
	}

}
